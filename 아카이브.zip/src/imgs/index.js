import paper from "./paper.png";
import rock from "./rock.png";
import scissors from "./scissors.png";
import srp from "./srp.png";

export { paper, rock, scissors, srp };
